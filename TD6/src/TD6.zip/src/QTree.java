import java.text.StringCharacterIterator;

public class QTree {


}
