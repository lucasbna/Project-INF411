
class EfficiencyMeasure {
}
