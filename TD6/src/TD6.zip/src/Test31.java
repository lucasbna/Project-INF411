
public class Test31 {

	public static void main(String[] args) {
		// Pour s'assurer que les assert's sont activés
		try {
			assert false;
			System.err.println("Vous devez activer l'option -ea de la JVM");
			System.err.println("(Run As -> Run configurations -> Arguments -> VM Arguments)");
			System.exit(1);
		} catch (AssertionError e) {
		}

		//TODO

	}


}
